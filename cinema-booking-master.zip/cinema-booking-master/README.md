# cinema-booking

Cinema Bookign files

# Simple javascript cinema booking example.
